
#ifndef SMIT9523_BUFFER_H
#define	SMIT9523_BUFFER_H

#include <xc.h> 
#ifdef	__cplusplus
extern "C" {
#endif /* __cplusplus */

    void putVal(int newValue);
    int getAvg();
    void initBuffer();
   

#ifdef	__cplusplus
}
#endif /* __cplusplus */

#endif	/* XC_HEADER_TEMPLATE_H */

